import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'MindFlow — Your AI Productivity OS',
  description: 'An AI-powered personal productivity OS that learns how your brain works. Organise your tasks, goals, and life in one place.',
  keywords: ['productivity', 'AI', 'task manager', 'goal tracking', 'life OS'],
  openGraph: {
    title: 'MindFlow — Your AI Productivity OS',
    description: 'Stop juggling apps. Let AI organise your life.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:ital,wght@0,300;0,400;1,300&family=Instrument+Serif:ital@0;1&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-bg text-white font-mono antialiased">
        {children}
      </body>
    </html>
  )
}
