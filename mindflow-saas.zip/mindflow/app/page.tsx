import Link from 'next/link'
import { ArrowRight, Zap, Brain, Target, Check, Star } from 'lucide-react'
import { PRICING_PLANS } from '@/lib/stripe'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#07080a] text-white font-mono overflow-x-hidden">

      {/* Ambient glow */}
      <div className="fixed top-0 left-0 w-[60vw] h-[60vh] bg-[radial-gradient(ellipse,rgba(0,245,160,0.04)_0%,transparent_70%)] pointer-events-none z-0" />
      <div className="fixed bottom-0 right-0 w-[50vw] h-[50vh] bg-[radial-gradient(ellipse,rgba(123,97,255,0.05)_0%,transparent_70%)] pointer-events-none z-0" />

      {/* NAV */}
      <nav className="relative z-20 flex items-center justify-between px-8 py-6 border-b border-[#1e2330] max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#00f5a0] rounded-lg flex items-center justify-center text-black font-syne font-black text-sm">M</div>
          <span className="font-syne font-bold text-lg">Mind<span className="text-[#00f5a0]">Flow</span></span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm text-[#9ca3af]">
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/auth/login" className="text-sm text-[#9ca3af] hover:text-white transition-colors px-4 py-2">
            Sign in
          </Link>
          <Link href="/auth/signup" className="text-sm bg-[#00f5a0] text-black font-medium px-4 py-2 rounded-lg hover:bg-[#00e090] transition-colors">
            Start free
          </Link>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pt-24 pb-20 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 border border-[rgba(0,245,160,0.3)] rounded-full text-[#00f5a0] text-xs mb-8 bg-[rgba(0,245,160,0.06)]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00f5a0] animate-pulse" />
          2.4 million people organised
        </div>

        <h1 className="font-syne font-black text-5xl md:text-7xl leading-[1.02] tracking-[-3px] max-w-4xl mx-auto mb-6">
          Your brain,{' '}
          <em className="not-italic font-serif-custom text-[#00f5a0]">finally</em>{' '}
          organised
        </h1>

        <p className="text-[#9ca3af] text-lg max-w-xl mx-auto mb-10 leading-relaxed">
          MindFlow is the AI-powered productivity OS that learns how you think —
          automatically capturing tasks, scheduling goals, and cutting through life's chaos.
        </p>

        <div className="flex items-center justify-center gap-4 flex-wrap">
          <Link
            href="/auth/signup"
            className="flex items-center gap-2 bg-[#00f5a0] text-black font-syne font-bold px-7 py-3.5 rounded-xl hover:bg-[#00e090] transition-all hover:scale-105"
          >
            Start for free <ArrowRight size={18} />
          </Link>
          <a
            href="#features"
            className="flex items-center gap-2 border border-[#1e2330] text-[#9ca3af] px-7 py-3.5 rounded-xl hover:border-[#2e3547] hover:text-white transition-all"
          >
            See how it works
          </a>
        </div>

        <p className="text-[#6b7280] text-xs mt-5">Free forever • No credit card needed • 2 min setup</p>

        {/* HERO MOCKUP */}
        <div className="mt-20 relative max-w-4xl mx-auto">
          <div className="bg-[#0e1014] border border-[#1e2330] rounded-2xl overflow-hidden shadow-2xl">
            {/* Window chrome */}
            <div className="flex items-center gap-2 px-5 py-3 border-b border-[#1e2330] bg-[#0a0b0e]">
              <div className="w-3 h-3 rounded-full bg-[#ff6b6b]" />
              <div className="w-3 h-3 rounded-full bg-[#ffd93d]" />
              <div className="w-3 h-3 rounded-full bg-[#00f5a0]" />
              <span className="ml-4 text-xs text-[#6b7280]">MindFlow Dashboard</span>
            </div>
            {/* Mock dashboard UI */}
            <div className="grid grid-cols-3 gap-0 text-left">
              {/* Sidebar */}
              <div className="border-r border-[#1e2330] p-5 col-span-1">
                <div className="text-xs text-[#6b7280] mb-4 uppercase tracking-wider">Today</div>
                {['Design new onboarding', 'Review Q3 metrics', 'Call with investors', 'Write blog post'].map((t, i) => (
                  <div key={i} className="flex items-center gap-2 py-2.5 border-b border-[rgba(255,255,255,0.04)] last:border-0">
                    <div className={`w-4 h-4 rounded border ${i === 0 ? 'bg-[#00f5a0] border-[#00f5a0]' : 'border-[#1e2330]'} flex items-center justify-center flex-shrink-0`}>
                      {i === 0 && <Check size={10} className="text-black" />}
                    </div>
                    <span className={`text-xs ${i === 0 ? 'line-through text-[#6b7280]' : 'text-[#9ca3af]'}`}>{t}</span>
                  </div>
                ))}
              </div>
              {/* Main area */}
              <div className="col-span-2 p-5">
                <div className="text-xs text-[#6b7280] mb-4 uppercase tracking-wider">Goals — this month</div>
                {[
                  { label: 'Launch MindFlow v2', pct: 74, color: '#00f5a0' },
                  { label: 'Exercise 4x/week', pct: 88, color: '#7b61ff' },
                  { label: 'Read 2 books', pct: 50, color: '#ffd93d' },
                ].map((g, i) => (
                  <div key={i} className="mb-4">
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-[#9ca3af]">{g.label}</span>
                      <span style={{ color: g.color }}>{g.pct}%</span>
                    </div>
                    <div className="h-1.5 bg-[rgba(255,255,255,0.06)] rounded-full">
                      <div className="h-full rounded-full" style={{ width: `${g.pct}%`, background: g.color }} />
                    </div>
                  </div>
                ))}
                <div className="mt-5 p-3 bg-[rgba(0,245,160,0.06)] border border-[rgba(0,245,160,0.15)] rounded-xl">
                  <div className="flex items-center gap-2 text-xs text-[#00f5a0] mb-1">
                    <Brain size={12} /> AI Insight
                  </div>
                  <p className="text-xs text-[#9ca3af]">Your peak focus window is 9–11am. I've scheduled your hardest tasks there.</p>
                </div>
              </div>
            </div>
          </div>
          {/* Glow under mockup */}
          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-3/4 h-12 bg-[#00f5a0] blur-3xl opacity-10 rounded-full" />
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section className="relative z-10 border-y border-[#1e2330] py-6 overflow-hidden">
        <div className="flex items-center gap-3 justify-center flex-wrap px-8">
          {['Saved 2hrs/day', '4.9★ on App Store', 'Used in 180+ countries', '98% retention', '#1 Product of the Day'].map((s, i) => (
            <span key={i} className="text-xs text-[#6b7280] px-4 py-2 border border-[#1e2330] rounded-full">{s}</span>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="relative z-10 max-w-7xl mx-auto px-8 py-24">
        <div className="text-center mb-16">
          <div className="text-xs text-[#00f5a0] tracking-[3px] uppercase mb-4">Why MindFlow</div>
          <h2 className="font-syne font-black text-4xl md:text-5xl tracking-tight mb-4">
            Built for how humans actually work
          </h2>
          <p className="text-[#9ca3af] max-w-lg mx-auto">Not another to-do list. A system that adapts to you.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: <Brain size={24} />,
              color: '#00f5a0',
              title: 'Adaptive Brain Model',
              desc: 'Learns your cognitive patterns, peak productivity windows, and decision-making style. Gets smarter every day you use it.',
            },
            {
              icon: <Zap size={24} />,
              color: '#7b61ff',
              title: 'Zero-Input Capture',
              desc: 'Automatically extracts tasks from emails, Slack, WhatsApp, and meetings. Never manually enter a task again.',
            },
            {
              icon: <Target size={24} />,
              color: '#ffd93d',
              title: 'Goal Cascade Engine',
              desc: 'Break life goals into daily micro-actions. MindFlow schedules them around your life automatically.',
            },
          ].map((f, i) => (
            <div key={i} className="bg-[#0e1014] border border-[#1e2330] rounded-2xl p-7 hover:border-[#2e3547] transition-colors group">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5" style={{ background: `rgba(${f.color === '#00f5a0' ? '0,245,160' : f.color === '#7b61ff' ? '123,97,255' : '255,217,61'},0.1)`, color: f.color }}>
                {f.icon}
              </div>
              <h3 className="font-syne font-bold text-lg mb-3">{f.title}</h3>
              <p className="text-sm text-[#9ca3af] leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pb-24">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { name: 'Sarah K.', role: 'Founder, TechStart', text: 'MindFlow replaced 5 apps for me. My team thinks I hired an EA — I just use this.' },
            { name: 'Marcus T.', role: 'Product Manager', text: 'The AI actually learns. After 2 weeks it was scheduling my day better than I ever could.' },
            { name: 'Priya M.', role: 'Freelance Designer', text: 'Finally hit my goals. The cascade feature breaks everything down so it\'s never overwhelming.' },
          ].map((t, i) => (
            <div key={i} className="bg-[#0e1014] border border-[#1e2330] rounded-2xl p-6">
              <div className="flex gap-0.5 mb-4">
                {[...Array(5)].map((_, j) => <Star key={j} size={14} fill="#ffd93d" stroke="none" />)}
              </div>
              <p className="text-sm text-[#9ca3af] leading-relaxed mb-5">"{t.text}"</p>
              <div>
                <div className="text-sm font-medium">{t.name}</div>
                <div className="text-xs text-[#6b7280]">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="relative z-10 max-w-7xl mx-auto px-8 pb-24">
        <div className="text-center mb-16">
          <div className="text-xs text-[#00f5a0] tracking-[3px] uppercase mb-4">Pricing</div>
          <h2 className="font-syne font-black text-4xl md:text-5xl tracking-tight mb-4">Simple, honest pricing</h2>
          <p className="text-[#9ca3af]">Start free. Upgrade when you're ready.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {PRICING_PLANS.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-[#0e1014] rounded-2xl p-7 flex flex-col ${
                plan.highlighted
                  ? 'border-2 border-[#00f5a0] shadow-[0_0_40px_rgba(0,245,160,0.1)]'
                  : 'border border-[#1e2330]'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#00f5a0] text-black text-xs font-syne font-bold px-4 py-1 rounded-full">
                  BEST VALUE
                </div>
              )}
              <div className="mb-6">
                <div className="text-sm text-[#9ca3af] mb-2">{plan.name}</div>
                <div className="font-syne font-black text-4xl tracking-tight">
                  {plan.price === 0 ? 'Free' : `$${plan.price}`}
                  {plan.price > 0 && (
                    <span className="text-sm font-mono font-normal text-[#6b7280]">
                      /{plan.interval}
                    </span>
                  )}
                </div>
              </div>
              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm text-[#9ca3af]">
                    <Check size={14} className="text-[#00f5a0] mt-0.5 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href={plan.price === 0 ? '/auth/signup' : `/auth/signup?plan=${plan.id}`}
                className={`text-center py-3 rounded-xl text-sm font-medium transition-all ${
                  plan.highlighted
                    ? 'bg-[#00f5a0] text-black hover:bg-[#00e090]'
                    : 'border border-[#1e2330] text-[#9ca3af] hover:border-[#2e3547] hover:text-white'
                }`}
              >
                {plan.price === 0 ? 'Get started free' : 'Start Pro'}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pb-24">
        <div className="bg-[#0e1014] border border-[#1e2330] rounded-3xl p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,245,160,0.05)_0%,transparent_70%)]" />
          <div className="relative z-10">
            <h2 className="font-syne font-black text-4xl md:text-5xl tracking-tight mb-4">
              Ready to get your life<br />
              <em className="not-italic font-serif-custom text-[#00f5a0]">under control?</em>
            </h2>
            <p className="text-[#9ca3af] mb-8 max-w-md mx-auto">Join 2.4 million people who stopped juggling apps and started actually achieving their goals.</p>
            <Link
              href="/auth/signup"
              className="inline-flex items-center gap-2 bg-[#00f5a0] text-black font-syne font-bold px-8 py-4 rounded-xl hover:bg-[#00e090] transition-all hover:scale-105"
            >
              Start free today <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-[#1e2330] py-8 px-8 max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 bg-[#00f5a0] rounded flex items-center justify-center text-black font-syne font-black text-xs">M</div>
          <span className="font-syne font-bold text-sm">MindFlow</span>
        </div>
        <div className="text-xs text-[#6b7280]">© 2025 MindFlow Inc. All rights reserved.</div>
        <div className="flex gap-6 text-xs text-[#6b7280]">
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
          <a href="#" className="hover:text-white transition-colors">Terms</a>
          <a href="#" className="hover:text-white transition-colors">Contact</a>
        </div>
      </footer>
    </div>
  )
}
