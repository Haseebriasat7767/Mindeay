'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Plus, Trash2, ChevronUp, ChevronDown } from 'lucide-react'
import type { Goal, GoalCategory, GoalStatus } from '@/types'
import { getCategoryEmoji } from '@/lib/utils'

const CATEGORIES: GoalCategory[] = ['health', 'career', 'finance', 'relationships', 'learning', 'other']

export default function GoalsPage() {
  const supabase = createClient()
  const [goals, setGoals] = useState<Goal[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    title: '', description: '', category: 'other' as GoalCategory, target_date: ''
  })

  useEffect(() => { fetchGoals() }, [])

  async function fetchGoals() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data } = await supabase.from('goals').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
    setGoals(data ?? [])
    setLoading(false)
  }

  async function addGoal(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase.from('goals').insert({
      user_id: user.id,
      title: form.title,
      description: form.description || null,
      category: form.category,
      target_date: form.target_date || null,
      progress: 0,
      status: 'active',
    }).select().single()

    if (data) {
      setGoals(prev => [data, ...prev])
      setForm({ title: '', description: '', category: 'other', target_date: '' })
      setShowForm(false)
    }
    setSaving(false)
  }

  async function updateProgress(goal: Goal, delta: number) {
    const newProgress = Math.max(0, Math.min(100, goal.progress + delta))
    const newStatus: GoalStatus = newProgress === 100 ? 'completed' : 'active'
    const { data } = await supabase.from('goals').update({
      progress: newProgress, status: newStatus, updated_at: new Date().toISOString(),
    }).eq('id', goal.id).select().single()
    if (data) setGoals(prev => prev.map(g => g.id === goal.id ? data : g))
  }

  async function deleteGoal(id: string) {
    await supabase.from('goals').delete().eq('id', id)
    setGoals(prev => prev.filter(g => g.id !== id))
  }

  const active = goals.filter(g => g.status === 'active')
  const completed = goals.filter(g => g.status === 'completed')

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-syne font-black text-3xl tracking-tight">Goals</h1>
          <p className="text-[#6b7280] text-sm mt-1">{active.length} active · {completed.length} completed</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-[#00f5a0] text-black font-syne font-bold px-4 py-2.5 rounded-xl hover:bg-[#00e090] transition-colors text-sm"
        >
          <Plus size={16} /> Add goal
        </button>
      </div>

      {showForm && (
        <form onSubmit={addGoal} className="bg-[#0e1014] border border-[#1e2330] rounded-2xl p-6 mb-6 space-y-4">
          <input
            required
            placeholder="Goal title"
            value={form.title}
            onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
            className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] transition-colors"
          />
          <textarea
            placeholder="Description (optional)"
            value={form.description}
            onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
            rows={2}
            className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] resize-none"
          />
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Category</label>
              <select
                value={form.category}
                onChange={e => setForm(p => ({ ...p, category: e.target.value as GoalCategory }))}
                className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00f5a0]"
              >
                {CATEGORIES.map(c => (
                  <option key={c} value={c}>{getCategoryEmoji(c)} {c.charAt(0).toUpperCase() + c.slice(1)}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Target Date</label>
              <input
                type="date"
                value={form.target_date}
                onChange={e => setForm(p => ({ ...p, target_date: e.target.value }))}
                className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00f5a0]"
              />
            </div>
          </div>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="bg-[#00f5a0] text-black font-syne font-bold px-5 py-2.5 rounded-xl hover:bg-[#00e090] text-sm disabled:opacity-60">
              {saving ? 'Saving...' : 'Add goal'}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="text-[#6b7280] hover:text-white text-sm px-4 py-2.5">Cancel</button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="text-center py-16 text-[#6b7280]">Loading goals...</div>
      ) : goals.length === 0 ? (
        <div className="text-center py-16 text-[#6b7280]">
          No goals yet. <button onClick={() => setShowForm(true)} className="text-[#00f5a0] hover:underline">Set your first goal →</button>
        </div>
      ) : (
        <div className="space-y-4">
          {goals.map(goal => (
            <div key={goal.id} className="group bg-[#0e1014] border border-[#1e2330] rounded-2xl p-6 hover:border-[#2e3547] transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getCategoryEmoji(goal.category)}</span>
                  <div>
                    <h3 className="font-syne font-bold text-base">{goal.title}</h3>
                    {goal.description && <p className="text-xs text-[#6b7280] mt-0.5">{goal.description}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {goal.status === 'completed' && (
                    <span className="text-xs bg-[rgba(0,245,160,0.1)] text-[#00f5a0] border border-[rgba(0,245,160,0.2)] px-3 py-1 rounded-full">
                      ✓ Done
                    </span>
                  )}
                  <button onClick={() => deleteGoal(goal.id)} className="opacity-0 group-hover:opacity-100 text-[#6b7280] hover:text-[#ff6b6b] transition-all">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-[#6b7280]">Progress</span>
                    <span className="text-[#00f5a0] font-medium">{goal.progress}%</span>
                  </div>
                  <div className="h-2 bg-[rgba(255,255,255,0.06)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#00f5a0] rounded-full transition-all duration-500"
                      style={{ width: `${goal.progress}%` }}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => updateProgress(goal, -10)}
                    disabled={goal.progress === 0}
                    className="w-7 h-7 flex items-center justify-center rounded-lg border border-[#1e2330] text-[#6b7280] hover:text-white hover:border-[#2e3547] transition-all disabled:opacity-30"
                  >
                    <ChevronDown size={14} />
                  </button>
                  <button
                    onClick={() => updateProgress(goal, 10)}
                    disabled={goal.progress === 100}
                    className="w-7 h-7 flex items-center justify-center rounded-lg border border-[#1e2330] text-[#6b7280] hover:text-[#00f5a0] hover:border-[rgba(0,245,160,0.3)] transition-all disabled:opacity-30"
                  >
                    <ChevronUp size={14} />
                  </button>
                </div>
              </div>

              {goal.target_date && (
                <p className="text-xs text-[#6b7280] mt-3">
                  Target: {new Date(goal.target_date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
