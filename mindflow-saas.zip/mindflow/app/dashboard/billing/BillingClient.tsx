'use client'

import { useState } from 'react'
import { Check, Zap, ExternalLink } from 'lucide-react'
import type { Subscription, PricingPlan } from '@/types'

export default function BillingClient({
  subscription,
  plans,
}: {
  subscription: Subscription | null
  plans: PricingPlan[]
}) {
  const [loading, setLoading] = useState<string | null>(null)
  const isPro = subscription?.plan === 'monthly' || subscription?.plan === 'yearly'

  async function handleUpgrade(plan: PricingPlan) {
    setLoading(plan.id)
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan: plan.id }),
    })
    const { url } = await res.json()
    if (url) window.location.href = url
    setLoading(null)
  }

  async function handleManageBilling() {
    setLoading('portal')
    const res = await fetch('/api/stripe/portal', { method: 'POST' })
    const { url } = await res.json()
    if (url) window.location.href = url
    setLoading(null)
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-10">
        <h1 className="font-syne font-black text-3xl tracking-tight">Billing</h1>
        <p className="text-[#6b7280] text-sm mt-1">Manage your plan and payment details</p>
      </div>

      {/* Current plan */}
      <div className="bg-[#0e1014] border border-[#1e2330] rounded-2xl p-6 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-[#6b7280] uppercase tracking-wider mb-1">Current Plan</p>
            <div className="flex items-center gap-2">
              <Zap size={16} className={isPro ? 'text-[#00f5a0]' : 'text-[#6b7280]'} />
              <span className="font-syne font-bold text-lg capitalize">
                {subscription?.plan ?? 'Free'}
              </span>
              {isPro && (
                <span className="text-xs bg-[rgba(0,245,160,0.1)] text-[#00f5a0] border border-[rgba(0,245,160,0.2)] px-2.5 py-0.5 rounded-full">
                  Active
                </span>
              )}
            </div>
            {subscription?.current_period_end && isPro && (
              <p className="text-xs text-[#6b7280] mt-1">
                Renews {new Date(subscription.current_period_end).toLocaleDateString('en-US', {
                  month: 'long', day: 'numeric', year: 'numeric',
                })}
              </p>
            )}
          </div>
          {isPro && (
            <button
              onClick={handleManageBilling}
              disabled={loading === 'portal'}
              className="flex items-center gap-2 border border-[#1e2330] text-[#9ca3af] hover:text-white hover:border-[#2e3547] px-4 py-2.5 rounded-xl text-sm transition-all disabled:opacity-60"
            >
              <ExternalLink size={14} />
              {loading === 'portal' ? 'Opening...' : 'Manage billing'}
            </button>
          )}
        </div>
      </div>

      {/* Plans */}
      <h2 className="font-syne font-bold text-lg mb-5">
        {isPro ? 'Change plan' : 'Upgrade to Pro'}
      </h2>

      <div className="grid gap-4">
        {plans.filter(p => p.price > 0).map(plan => {
          const isCurrent = subscription?.plan === plan.id
          return (
            <div
              key={plan.id}
              className={`bg-[#0e1014] rounded-2xl p-6 border transition-all ${
                plan.highlighted
                  ? 'border-[#00f5a0] shadow-[0_0_30px_rgba(0,245,160,0.08)]'
                  : 'border-[#1e2330]'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-syne font-bold text-base">{plan.name}</h3>
                    {plan.highlighted && (
                      <span className="text-xs bg-[rgba(0,245,160,0.1)] text-[#00f5a0] border border-[rgba(0,245,160,0.2)] px-2.5 py-0.5 rounded-full">
                        Best value
                      </span>
                    )}
                    {isCurrent && (
                      <span className="text-xs bg-[rgba(123,97,255,0.1)] text-[#7b61ff] border border-[rgba(123,97,255,0.2)] px-2.5 py-0.5 rounded-full">
                        Current
                      </span>
                    )}
                  </div>
                  <div className="font-syne font-black text-3xl mb-4">
                    ${plan.price}
                    <span className="text-sm font-mono font-normal text-[#6b7280]">/{plan.interval}</span>
                  </div>
                  <ul className="grid grid-cols-2 gap-2">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-[#9ca3af]">
                        <Check size={12} className="text-[#00f5a0] flex-shrink-0" /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="ml-8 flex-shrink-0">
                  {isCurrent ? (
                    <button
                      onClick={handleManageBilling}
                      className="border border-[#1e2330] text-[#9ca3af] px-5 py-2.5 rounded-xl text-sm hover:border-[#2e3547] hover:text-white transition-all"
                    >
                      Manage
                    </button>
                  ) : (
                    <button
                      onClick={() => handleUpgrade(plan)}
                      disabled={loading === plan.id}
                      className={`px-5 py-2.5 rounded-xl text-sm font-syne font-bold transition-all disabled:opacity-60 ${
                        plan.highlighted
                          ? 'bg-[#00f5a0] text-black hover:bg-[#00e090]'
                          : 'bg-[#1e2330] text-white hover:bg-[#2e3547]'
                      }`}
                    >
                      {loading === plan.id ? 'Loading...' : `Upgrade to ${plan.interval === 'year' ? 'yearly' : 'monthly'}`}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <p className="text-xs text-[#6b7280] text-center mt-6">
        Payments secured by Stripe · Cancel anytime · No hidden fees
      </p>
    </div>
  )
}
