import { createServerClient } from '@/lib/supabase/server'
import { PRICING_PLANS } from '@/lib/stripe'
import BillingClient from './BillingClient'

export default async function BillingPage() {
  const supabase = createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: subscription } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', user!.id)
    .single()

  return <BillingClient subscription={subscription} plans={PRICING_PLANS} />
}
