import { createServerClient } from '@/lib/supabase/server'
import { CheckCircle, Target, Zap, TrendingUp } from 'lucide-react'
import Link from 'next/link'

export default async function DashboardPage() {
  const supabase = createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [{ data: tasks }, { data: goals }, { data: profile }, { data: sub }] = await Promise.all([
    supabase.from('tasks').select('*').eq('user_id', user!.id).order('created_at', { ascending: false }),
    supabase.from('goals').select('*').eq('user_id', user!.id).eq('status', 'active'),
    supabase.from('profiles').select('*').eq('id', user!.id).single(),
    supabase.from('subscriptions').select('*').eq('user_id', user!.id).single(),
  ])

  const todayTasks = tasks?.filter(t => t.status !== 'done').slice(0, 5) ?? []
  const doneTasks = tasks?.filter(t => t.status === 'done').length ?? 0
  const totalTasks = tasks?.length ?? 0
  const isPro = sub?.plan === 'monthly' || sub?.plan === 'yearly'

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const firstName = profile?.full_name?.split(' ')[0] ?? 'there'

  return (
    <div className="max-w-5xl mx-auto">

      {/* Header */}
      <div className="mb-10">
        <p className="text-[#6b7280] text-sm mb-1">{greeting},</p>
        <h1 className="font-syne font-black text-4xl tracking-tight">
          {firstName} <span className="text-[#00f5a0]">👋</span>
        </h1>
        <p className="text-[#6b7280] text-sm mt-2">
          {todayTasks.length === 0
            ? "You're all caught up. Add some tasks to get started."
            : `You have ${todayTasks.length} tasks waiting for you.`}
        </p>
      </div>

      {/* Upgrade banner for free users */}
      {!isPro && (
        <div className="mb-8 bg-[rgba(123,97,255,0.08)] border border-[rgba(123,97,255,0.25)] rounded-2xl p-5 flex items-center justify-between">
          <div>
            <p className="font-syne font-bold text-sm mb-1">Unlock the full AI Brain Model</p>
            <p className="text-xs text-[#9ca3af]">Upgrade to Pro for unlimited tasks, goals, and AI-powered scheduling.</p>
          </div>
          <Link
            href="/dashboard/billing"
            className="flex-shrink-0 ml-6 bg-[#7b61ff] text-white text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-[#6a50ee] transition-colors"
          >
            Upgrade →
          </Link>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Tasks done', value: doneTasks, icon: <CheckCircle size={18} />, color: '#00f5a0' },
          { label: 'Total tasks', value: totalTasks, icon: <Zap size={18} />, color: '#7b61ff' },
          { label: 'Active goals', value: goals?.length ?? 0, icon: <Target size={18} />, color: '#ffd93d' },
          { label: 'Completion', value: totalTasks > 0 ? `${Math.round((doneTasks / totalTasks) * 100)}%` : '0%', icon: <TrendingUp size={18} />, color: '#ff6b6b' },
        ].map((s, i) => (
          <div key={i} className="bg-[#0e1014] border border-[#1e2330] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-[#6b7280] uppercase tracking-wider">{s.label}</span>
              <span style={{ color: s.color }}>{s.icon}</span>
            </div>
            <div className="font-syne font-black text-3xl" style={{ color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Main content grid */}
      <div className="grid grid-cols-3 gap-6">

        {/* Tasks */}
        <div className="col-span-2 bg-[#0e1014] border border-[#1e2330] rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#1e2330]">
            <h2 className="font-syne font-bold text-base">Today's Tasks</h2>
            <Link href="/dashboard/tasks" className="text-xs text-[#00f5a0] hover:underline">View all →</Link>
          </div>
          <div className="divide-y divide-[rgba(255,255,255,0.04)]">
            {todayTasks.length === 0 ? (
              <div className="px-6 py-10 text-center text-[#6b7280] text-sm">
                No pending tasks. <Link href="/dashboard/tasks" className="text-[#00f5a0] hover:underline">Add one →</Link>
              </div>
            ) : (
              todayTasks.map(task => (
                <div key={task.id} className="flex items-center gap-4 px-6 py-4">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                    task.priority === 'urgent' ? 'bg-[#ff3b3b]' :
                    task.priority === 'high' ? 'bg-[#ff6b6b]' :
                    task.priority === 'medium' ? 'bg-[#ffd93d]' : 'bg-[#6b7280]'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">{task.title}</p>
                    {task.due_date && (
                      <p className="text-xs text-[#6b7280] mt-0.5">
                        Due {new Date(task.due_date).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-[#6b7280] capitalize">{task.status.replace('_', ' ')}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Goals sidebar */}
        <div className="bg-[#0e1014] border border-[#1e2330] rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#1e2330]">
            <h2 className="font-syne font-bold text-base">Goals</h2>
            <Link href="/dashboard/goals" className="text-xs text-[#00f5a0] hover:underline">All →</Link>
          </div>
          <div className="p-5 space-y-5">
            {goals?.length === 0 ? (
              <p className="text-[#6b7280] text-sm text-center py-6">
                No goals yet. <Link href="/dashboard/goals" className="text-[#00f5a0] hover:underline">Add one →</Link>
              </p>
            ) : (
              goals?.slice(0, 4).map(goal => (
                <div key={goal.id}>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-sm truncate flex-1">{goal.title}</span>
                    <span className="text-xs text-[#00f5a0] ml-2">{goal.progress}%</span>
                  </div>
                  <div className="h-1.5 bg-[rgba(255,255,255,0.06)] rounded-full">
                    <div
                      className="h-full bg-[#00f5a0] rounded-full transition-all"
                      style={{ width: `${goal.progress}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  )
}
