'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Plus, Trash2, CheckCircle, Circle } from 'lucide-react'
import type { Task, TaskStatus, TaskPriority } from '@/types'

const PRIORITIES: TaskPriority[] = ['low', 'medium', 'high', 'urgent']
const PRIORITY_COLORS: Record<TaskPriority, string> = {
  low: '#6b7280', medium: '#ffd93d', high: '#ff6b6b', urgent: '#ff3b3b'
}

export default function TasksPage() {
  const supabase = createClient()
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [filter, setFilter] = useState<TaskStatus | 'all'>('all')
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium' as TaskPriority, due_date: '' })
  const [saving, setSaving] = useState(false)

  useEffect(() => { fetchTasks() }, [])

  async function fetchTasks() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data } = await supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
    setTasks(data ?? [])
    setLoading(false)
  }

  async function addTask(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase.from('tasks').insert({
      user_id: user.id,
      title: form.title,
      description: form.description || null,
      priority: form.priority,
      due_date: form.due_date || null,
      status: 'todo',
    }).select().single()

    if (data) {
      setTasks(prev => [data, ...prev])
      setForm({ title: '', description: '', priority: 'medium', due_date: '' })
      setShowForm(false)
    }
    setSaving(false)
  }

  async function toggleTask(task: Task) {
    const newStatus: TaskStatus = task.status === 'done' ? 'todo' : 'done'
    const { data } = await supabase.from('tasks').update({
      status: newStatus,
      completed_at: newStatus === 'done' ? new Date().toISOString() : null,
    }).eq('id', task.id).select().single()
    if (data) setTasks(prev => prev.map(t => t.id === task.id ? data : t))
  }

  async function deleteTask(id: string) {
    await supabase.from('tasks').delete().eq('id', id)
    setTasks(prev => prev.filter(t => t.id !== id))
  }

  const filtered = filter === 'all' ? tasks : tasks.filter(t => t.status === filter)

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-syne font-black text-3xl tracking-tight">Tasks</h1>
          <p className="text-[#6b7280] text-sm mt-1">{tasks.filter(t => t.status !== 'done').length} remaining</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-[#00f5a0] text-black font-syne font-bold px-4 py-2.5 rounded-xl hover:bg-[#00e090] transition-colors text-sm"
        >
          <Plus size={16} /> Add task
        </button>
      </div>

      {/* Add task form */}
      {showForm && (
        <form onSubmit={addTask} className="bg-[#0e1014] border border-[#1e2330] rounded-2xl p-6 mb-6 space-y-4">
          <input
            required
            placeholder="Task title"
            value={form.title}
            onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
            className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] transition-colors"
          />
          <textarea
            placeholder="Description (optional)"
            value={form.description}
            onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
            rows={2}
            className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] transition-colors resize-none"
          />
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Priority</label>
              <select
                value={form.priority}
                onChange={e => setForm(p => ({ ...p, priority: e.target.value as TaskPriority }))}
                className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00f5a0] transition-colors"
              >
                {PRIORITIES.map(p => <option key={p} value={p} className="capitalize">{p}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Due Date</label>
              <input
                type="date"
                value={form.due_date}
                onChange={e => setForm(p => ({ ...p, due_date: e.target.value }))}
                className="w-full bg-[#141720] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#00f5a0] transition-colors"
              />
            </div>
          </div>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="bg-[#00f5a0] text-black font-syne font-bold px-5 py-2.5 rounded-xl hover:bg-[#00e090] text-sm disabled:opacity-60">
              {saving ? 'Saving...' : 'Add task'}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="text-[#6b7280] hover:text-white text-sm px-4 py-2.5 transition-colors">
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Filter tabs */}
      <div className="flex gap-2 mb-6">
        {(['all', 'todo', 'in_progress', 'done'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-xs transition-all capitalize ${
              filter === f
                ? 'bg-[rgba(0,245,160,0.1)] text-[#00f5a0] border border-[rgba(0,245,160,0.2)]'
                : 'text-[#6b7280] hover:text-white border border-[#1e2330]'
            }`}
          >
            {f.replace('_', ' ')}
            <span className="ml-1.5 text-[#6b7280]">
              {f === 'all' ? tasks.length : tasks.filter(t => t.status === f).length}
            </span>
          </button>
        ))}
      </div>

      {/* Task list */}
      <div className="space-y-2">
        {loading ? (
          <div className="text-center py-16 text-[#6b7280]">Loading tasks...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-[#6b7280]">
            No tasks here. <button onClick={() => setShowForm(true)} className="text-[#00f5a0] hover:underline">Add one?</button>
          </div>
        ) : (
          filtered.map(task => (
            <div
              key={task.id}
              className={`group flex items-center gap-4 bg-[#0e1014] border rounded-xl px-5 py-4 transition-all ${
                task.status === 'done' ? 'border-[rgba(255,255,255,0.04)] opacity-60' : 'border-[#1e2330] hover:border-[#2e3547]'
              }`}
            >
              <button onClick={() => toggleTask(task)} className="flex-shrink-0 text-[#6b7280] hover:text-[#00f5a0] transition-colors">
                {task.status === 'done'
                  ? <CheckCircle size={20} className="text-[#00f5a0]" />
                  : <Circle size={20} />}
              </button>
              <div
                className="w-2 h-2 rounded-full flex-shrink-0"
                style={{ background: PRIORITY_COLORS[task.priority] }}
              />
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${task.status === 'done' ? 'line-through text-[#6b7280]' : ''}`}>
                  {task.title}
                </p>
                {task.due_date && (
                  <p className="text-xs text-[#6b7280] mt-0.5">
                    Due {new Date(task.due_date).toLocaleDateString()}
                  </p>
                )}
              </div>
              <span className={`text-xs px-2.5 py-1 rounded-lg capitalize ${
                task.priority === 'urgent' ? 'bg-[rgba(255,59,59,0.15)] text-[#ff3b3b]' :
                task.priority === 'high' ? 'bg-[rgba(255,107,107,0.15)] text-[#ff6b6b]' :
                task.priority === 'medium' ? 'bg-[rgba(255,217,61,0.15)] text-[#ffd93d]' :
                'bg-[rgba(107,114,128,0.15)] text-[#6b7280]'
              }`}>
                {task.priority}
              </span>
              <button
                onClick={() => deleteTask(task.id)}
                className="opacity-0 group-hover:opacity-100 text-[#6b7280] hover:text-[#ff6b6b] transition-all"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
