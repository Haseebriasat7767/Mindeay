'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Eye, EyeOff, ArrowRight } from 'lucide-react'

export default function SignupPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const plan = searchParams.get('plan') || 'free'
  const supabase = createClient()

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: name },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    })

    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }

    // If paid plan selected, redirect to checkout after signup
    if (plan !== 'free' && data.user) {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan, userId: data.user.id, email }),
      })
      const { url } = await res.json()
      if (url) { window.location.href = url; return }
    }

    router.push('/dashboard')
    router.refresh()
  }

  return (
    <div className="min-h-screen bg-[#07080a] flex items-center justify-center px-4">
      <div className="fixed top-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_70%_20%,rgba(123,97,255,0.05)_0%,transparent_60%)] pointer-events-none" />

      <div className="w-full max-w-sm relative z-10">
        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-2 mb-8">
            <div className="w-8 h-8 bg-[#00f5a0] rounded-lg flex items-center justify-center text-black font-syne font-black text-sm">M</div>
            <span className="font-syne font-bold text-lg">Mind<span className="text-[#00f5a0]">Flow</span></span>
          </Link>
          <h1 className="font-syne font-bold text-2xl tracking-tight">Create your account</h1>
          <p className="text-[#6b7280] text-sm mt-2">
            {plan !== 'free' ? `Starting ${plan} plan` : 'Start free, upgrade anytime'}
          </p>
        </div>

        <form onSubmit={handleSignup} className="space-y-4">
          {error && (
            <div className="bg-[rgba(255,107,107,0.1)] border border-[rgba(255,107,107,0.3)] text-[#ff6b6b] text-sm px-4 py-3 rounded-xl">
              {error}
            </div>
          )}

          <div>
            <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Your name"
              className="w-full bg-[#0e1014] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] transition-colors"
            />
          </div>

          <div>
            <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full bg-[#0e1014] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] transition-colors"
            />
          </div>

          <div>
            <label className="text-xs text-[#6b7280] uppercase tracking-wider block mb-2">Password</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                required
                minLength={8}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Min. 8 characters"
                className="w-full bg-[#0e1014] border border-[#1e2330] rounded-xl px-4 py-3 text-sm text-white placeholder-[#6b7280] focus:outline-none focus:border-[#00f5a0] transition-colors pr-11"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6b7280] hover:text-white transition-colors"
              >
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-[#00f5a0] text-black font-syne font-bold py-3.5 rounded-xl hover:bg-[#00e090] transition-all disabled:opacity-60 disabled:cursor-not-allowed mt-2"
          >
            {loading ? 'Creating account...' : <>Create account <ArrowRight size={16} /></>}
          </button>

          <p className="text-center text-xs text-[#6b7280] mt-2">
            By signing up you agree to our{' '}
            <a href="#" className="text-[#9ca3af] hover:text-white">Terms</a>
            {' & '}
            <a href="#" className="text-[#9ca3af] hover:text-white">Privacy Policy</a>
          </p>
        </form>

        <p className="text-center text-sm text-[#6b7280] mt-6">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-[#00f5a0] hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
