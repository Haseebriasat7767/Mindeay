# 🚀 MindFlow — Full SaaS Stack
### Deploy your AI productivity SaaS in under 30 minutes

---

## What's included

```
mindflow/
├── app/
│   ├── page.tsx                    ← Landing page (marketing)
│   ├── layout.tsx                  ← Root layout
│   ├── globals.css
│   ├── auth/
│   │   ├── login/page.tsx          ← Login page
│   │   └── signup/page.tsx         ← Signup (with plan selection)
│   ├── dashboard/
│   │   ├── layout.tsx              ← Dashboard shell (auth protected)
│   │   ├── page.tsx                ← Main dashboard
│   │   ├── tasks/page.tsx          ← Tasks CRUD
│   │   ├── goals/page.tsx          ← Goals with progress tracking
│   │   └── billing/                ← Stripe billing + upgrade flow
│   └── api/
│       ├── auth/callback/          ← Supabase OAuth callback
│       ├── stripe/checkout/        ← Create Stripe checkout session
│       ├── stripe/webhook/         ← Handle Stripe events (payments!)
│       └── stripe/portal/          ← Stripe customer portal
├── components/
│   └── dashboard/Sidebar.tsx       ← Dashboard navigation
├── lib/
│   ├── supabase/client.ts          ← Browser Supabase client
│   ├── supabase/server.ts          ← Server Supabase client
│   ├── stripe.ts                   ← Stripe + pricing plans config
│   └── utils.ts                    ← Helpers
├── supabase/migrations/
│   └── 001_initial_schema.sql      ← Full database schema
├── types/index.ts                  ← TypeScript types
└── middleware.ts                   ← Auth route protection
```

---

## Step 1 — Install dependencies

```bash
cd mindflow
npm install
```

---

## Step 2 — Set up Supabase (free)

1. Go to **https://supabase.com** → Create new project
2. Wait for it to spin up (~2 min)
3. Go to **SQL Editor** → paste entire contents of `supabase/migrations/001_initial_schema.sql` → Run
4. Go to **Project Settings → API** → copy:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY`

5. Go to **Authentication → URL Configuration** → add:
   - Site URL: `http://localhost:3000` (change to your domain when live)
   - Redirect URLs: `http://localhost:3000/api/auth/callback`

---

## Step 3 — Set up Stripe (free account)

1. Go to **https://dashboard.stripe.com** → Create account
2. Go to **Developers → API Keys** → copy:
   - Publishable key → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
   - Secret key → `STRIPE_SECRET_KEY`

3. Go to **Products → Add product**:
   - Create **"MindFlow Pro Monthly"** — $12/month recurring
   - Create **"MindFlow Pro Yearly"** — $99/year recurring
   - Copy both **Price IDs** (start with `price_...`)

4. Go to **Developers → Webhooks → Add endpoint**:
   - URL: `https://yourdomain.com/api/stripe/webhook`
   - Events to listen for:
     - `checkout.session.completed`
     - `customer.subscription.updated`
     - `customer.subscription.deleted`
     - `invoice.payment_failed`
   - Copy **Signing secret** → `STRIPE_WEBHOOK_SECRET`

5. Enable **Customer Portal** at: https://dashboard.stripe.com/settings/billing/portal

---

## Step 4 — Configure environment

```bash
cp .env.example .env.local
```

Fill in `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

STRIPE_PRICE_MONTHLY=price_...
STRIPE_PRICE_YEARLY=price_...

NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## Step 5 — Run locally

```bash
npm run dev
```

Open **http://localhost:3000**

To test Stripe webhooks locally (in a second terminal):
```bash
npm run stripe:listen
```
(Requires Stripe CLI: https://stripe.com/docs/stripe-cli)

---

## Step 6 — Deploy to Vercel (free)

1. Push your code to a GitHub repo
2. Go to **https://vercel.com** → Import project
3. Add all environment variables from `.env.local`
4. Change `NEXT_PUBLIC_APP_URL` to your Vercel URL
5. Deploy!

After deploy:
- Update Supabase redirect URL to your Vercel URL
- Update Stripe webhook URL to your Vercel URL

---

## How money flows

```
User visits → Signs up free
     ↓
Clicks "Upgrade" → /dashboard/billing
     ↓
POST /api/stripe/checkout → Stripe Checkout page
     ↓
User pays → Stripe fires webhook
     ↓
POST /api/stripe/webhook → Updates Supabase subscriptions table
     ↓
User now has Pro access 💰
```

---

## Customise pricing

Edit `lib/stripe.ts` — change `PRICING_PLANS` array:
- Update prices
- Add/remove features
- Change plan names

---

## Customise the product

The product is "MindFlow" but you can rename it globally by:
1. Find/replace `MindFlow` → Your product name
2. Find/replace `mindflow` → your-product-slug
3. Update `app/layout.tsx` metadata

---

## Add more features

The database schema is ready for extension. Add new tables in Supabase SQL editor and create new pages under `app/dashboard/`.

---

## Support

Built with:
- **Next.js 14** (App Router)
- **Supabase** (auth + database + RLS)
- **Stripe** (payments + webhooks + portal)
- **Tailwind CSS** (styling)
- **TypeScript** (type safety)

All free tiers are generous enough to get to $10K MRR before paying anything.
