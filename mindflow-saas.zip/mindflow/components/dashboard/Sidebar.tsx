'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { LayoutDashboard, CheckSquare, Target, CreditCard, LogOut, Zap } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import type { Profile, Subscription } from '@/types'

const NAV = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/dashboard/tasks', icon: CheckSquare, label: 'Tasks' },
  { href: '/dashboard/goals', icon: Target, label: 'Goals' },
  { href: '/dashboard/billing', icon: CreditCard, label: 'Billing' },
]

export default function DashboardSidebar({
  profile,
  subscription,
}: {
  profile: Profile | null
  subscription: Subscription | null
}) {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  const isPro = subscription?.plan === 'monthly' || subscription?.plan === 'yearly'

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/')
    router.refresh()
  }

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-[#0e1014] border-r border-[#1e2330] flex flex-col z-20">
      {/* Logo */}
      <div className="px-6 py-6 border-b border-[#1e2330]">
        <Link href="/" className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-[#00f5a0] rounded-lg flex items-center justify-center text-black font-syne font-black text-xs">M</div>
          <span className="font-syne font-bold">Mind<span className="text-[#00f5a0]">Flow</span></span>
        </Link>
      </div>

      {/* Plan badge */}
      <div className="px-4 pt-4 pb-2">
        <div className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs ${
          isPro
            ? 'bg-[rgba(0,245,160,0.08)] border border-[rgba(0,245,160,0.2)] text-[#00f5a0]'
            : 'bg-[rgba(255,255,255,0.04)] border border-[#1e2330] text-[#6b7280]'
        }`}>
          <Zap size={12} />
          {isPro ? `Pro ${subscription?.plan}` : 'Free plan'}
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-2">
        {NAV.map(item => {
          const active = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm mb-1 transition-all ${
                active
                  ? 'bg-[rgba(0,245,160,0.1)] text-[#00f5a0] border border-[rgba(0,245,160,0.2)]'
                  : 'text-[#6b7280] hover:text-white hover:bg-[rgba(255,255,255,0.04)]'
              }`}
            >
              <item.icon size={16} />
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* User */}
      <div className="px-4 py-4 border-t border-[#1e2330]">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 bg-[#1e2330] rounded-lg flex items-center justify-center text-xs font-medium text-[#9ca3af]">
            {profile?.full_name?.[0]?.toUpperCase() ?? '?'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm truncate">{profile?.full_name ?? 'User'}</p>
            <p className="text-xs text-[#6b7280] truncate">{profile?.email}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-[#6b7280] hover:text-[#ff6b6b] hover:bg-[rgba(255,107,107,0.06)] transition-all"
        >
          <LogOut size={14} />
          Sign out
        </button>
      </div>
    </aside>
  )
}
