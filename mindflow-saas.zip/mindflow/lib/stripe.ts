// lib/stripe.ts
import Stripe from 'stripe'
import { PricingPlan } from '@/types'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
})

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    interval: 'month',
    priceId: '',
    features: [
      'Up to 20 tasks',
      '3 active goals',
      'Basic AI suggestions',
      'Email support',
    ],
  },
  {
    id: 'monthly',
    name: 'Pro Monthly',
    price: 12,
    interval: 'month',
    priceId: process.env.STRIPE_PRICE_MONTHLY!,
    highlighted: false,
    features: [
      'Unlimited tasks',
      'Unlimited goals',
      'Full AI Brain Model',
      'Zero-input capture',
      'Calendar sync (14 providers)',
      'Priority support',
    ],
  },
  {
    id: 'yearly',
    name: 'Pro Yearly',
    price: 99,
    interval: 'year',
    priceId: process.env.STRIPE_PRICE_YEARLY!,
    highlighted: true,
    features: [
      'Everything in Monthly',
      'Save $45/year (31% off)',
      'Early access to new features',
      'Goal Cascade Engine',
      'Advanced analytics',
      'Dedicated support',
    ],
  },
]

// Create or retrieve a Stripe customer for a user
export async function getOrCreateStripeCustomer(
  userId: string,
  email: string,
  existingCustomerId?: string | null
): Promise<string> {
  if (existingCustomerId) return existingCustomerId

  const customer = await stripe.customers.create({
    email,
    metadata: { supabase_user_id: userId },
  })

  return customer.id
}
