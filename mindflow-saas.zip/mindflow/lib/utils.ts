import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | null): string {
  if (!date) return '—'
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

export function formatPrice(price: number, interval: 'month' | 'year'): string {
  return `$${price}/${interval === 'month' ? 'mo' : 'yr'}`
}

export function getPriorityColor(priority: string): string {
  const map: Record<string, string> = {
    low: '#6b7280',
    medium: '#ffd93d',
    high: '#ff6b6b',
    urgent: '#ff3b3b',
  }
  return map[priority] ?? '#6b7280'
}

export function getCategoryEmoji(category: string): string {
  const map: Record<string, string> = {
    health: '💪',
    career: '🚀',
    finance: '💰',
    relationships: '❤️',
    learning: '🧠',
    other: '⭐',
  }
  return map[category] ?? '⭐'
}
