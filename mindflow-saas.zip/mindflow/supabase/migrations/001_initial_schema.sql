-- ============================================
-- MINDFLOW DATABASE SCHEMA
-- Run this in Supabase SQL editor
-- ============================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- -----------------------------------------------
-- PROFILES — extends Supabase auth.users
-- -----------------------------------------------
create table public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  email text not null,
  full_name text,
  avatar_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name'
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- -----------------------------------------------
-- SUBSCRIPTIONS — Stripe subscription state
-- -----------------------------------------------
create table public.subscriptions (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  stripe_price_id text,
  plan text check (plan in ('free', 'monthly', 'yearly')) default 'free',
  status text check (status in ('active', 'canceled', 'past_due', 'trialing', 'incomplete')) default 'active',
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- -----------------------------------------------
-- TASKS — Core product: user tasks
-- -----------------------------------------------
create table public.tasks (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  title text not null,
  description text,
  status text check (status in ('todo', 'in_progress', 'done')) default 'todo',
  priority text check (priority in ('low', 'medium', 'high', 'urgent')) default 'medium',
  due_date timestamptz,
  completed_at timestamptz,
  tags text[] default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- -----------------------------------------------
-- GOALS — Life goals tracked by MindFlow
-- -----------------------------------------------
create table public.goals (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  title text not null,
  description text,
  category text check (category in ('health', 'career', 'finance', 'relationships', 'learning', 'other')) default 'other',
  target_date timestamptz,
  progress integer default 0 check (progress >= 0 and progress <= 100),
  status text check (status in ('active', 'completed', 'paused')) default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- -----------------------------------------------
-- ROW LEVEL SECURITY — Users only see own data
-- -----------------------------------------------
alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.tasks enable row level security;
alter table public.goals enable row level security;

-- Profiles
create policy "Users can view own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);

-- Subscriptions
create policy "Users can view own subscription" on public.subscriptions for select using (auth.uid() = user_id);

-- Tasks
create policy "Users can CRUD own tasks" on public.tasks for all using (auth.uid() = user_id);

-- Goals
create policy "Users can CRUD own goals" on public.goals for all using (auth.uid() = user_id);

-- -----------------------------------------------
-- INDEXES for performance
-- -----------------------------------------------
create index tasks_user_id_idx on public.tasks(user_id);
create index tasks_status_idx on public.tasks(user_id, status);
create index goals_user_id_idx on public.goals(user_id);
create index subscriptions_user_id_idx on public.subscriptions(user_id);
create index subscriptions_stripe_customer_idx on public.subscriptions(stripe_customer_id);
